# -*- coding: utf-8 -*-
import importlib
import os
import sys

PKG_DIR = os.path.dirname(os.path.abspath(__file__))

# Zip instalado com o QGIS aberto: o QGIS descarrega o plugin, mas so tira da memoria os modulos que viu importados
# pelo nome. Um subpacote importado so no meio do caminho (o 'ui' de 'from .ui.dock import ...') ficava da versao
# anterior, apontando para a pasta antiga: "No module named 'agrokit.cad.engine'". Carregar este arquivo ja quer
# dizer versao nova, entao nada que sobrou da anterior serve.
for _m in [m for m in sys.modules if m.startswith(__name__ + '.')]:
    del sys.modules[_m]
importlib.invalidate_caches()


def _marca():
    """Muda quando a pasta e reinstalada (o zip grava os arquivos de novo)."""
    try:
        return os.stat(os.path.join(PKG_DIR, '__init__.py')).st_mtime_ns
    except OSError:
        return None


_MARCA = _marca()

# Pacote de avaliacao: o codigo vem compilado em _bin/pyXY, uma pasta por versao do Python (o QGIS 3.36 usa o 3.9,
# o 3.40 usa o 3.12...). Aqui escolhemos a pasta do Python deste QGIS; no codigo-fonte essa pasta nao existe.
_BIN = os.path.join(PKG_DIR, '_bin')
_ERRO = None
if os.path.isdir(_BIN):
    _dir = os.path.join(_BIN, 'py%d%d' % sys.version_info[:2])
    if os.path.isdir(_dir):
        __path__.insert(0, _dir)
    else:
        _tem = sorted((d[2:3] + '.' + d[3:] for d in os.listdir(_BIN) if d.startswith('py')), key=lambda v: int(v.split('.')[1]))
        _ERRO = ('Este pacote do AgroKit não tem versão para o Python %d.%d deste QGIS (o pacote traz: Python %s).\n\n'
                 'Instale o QGIS LTR mais recente (qgis.org → Download → versão LTR) ou peça ao autor um pacote para esta '
                 'versão do QGIS.' % (sys.version_info[0], sys.version_info[1], ', '.join(_tem) or '—'))


class _Aviso:
    """Plugin minimo que so explica por que o AgroKit nao pode carregar neste QGIS."""

    def __init__(self, iface, msg):
        self.iface, self.msg = iface, msg

    def initGui(self):
        from qgis.PyQt.QtWidgets import QMessageBox
        try:
            self.iface.messageBar().pushCritical('AgroKit', self.msg.split('\n')[0])
        except Exception:
            pass
        QMessageBox.warning(self.iface.mainWindow(), 'AgroKit', self.msg)

    def unload(self):
        pass


def classFactory(iface):
    if _marca() != _MARCA:
        # Pasta reinstalada sem o QGIS descarregar este modulo (acontece quando a carga anterior falhou): carrega
        # tudo de novo do disco, senao rodaria o codigo da versao anterior.
        for m in [m for m in sys.modules if m == __name__ or m.startswith(__name__ + '.')]:
            del sys.modules[m]
        return __import__(__name__).classFactory(iface)
    if _ERRO:
        return _Aviso(iface, _ERRO)
    from .plugin import AgroKitPlugin
    return AgroKitPlugin(iface)
